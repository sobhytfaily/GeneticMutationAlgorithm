
canvas = document.getElementById("canvas");
ctx = this.canvas.getContext("2d");


class Circle
{
    constructor(x, y, r)
    {
        this.x = x;
        this.y = y;
        this.r = r;
    }
}

function toBinary(circle)
{
    var x = addZeros(circle.x.toString(2));
    var y = addZeros(circle.y.toString(2));
    var r = addZeros(circle.r.toString(2));
    return x + y + r;
}
var originalCircles = [];

function generateOriginalPopulation(numberOfCircles)
{
    
    while(originalCircles.length != numberOfCircles)
    {
        var r = Math.floor(Math.random()*400);
        var x = Math.floor(Math.random()*800);
        var y = Math.floor(Math.random()*800);

        var testCricle = new Circle(x, y, r);
        if(circleInsideCanvas(testCricle)){
        if(!circleCollidesWithArrayOfCircles(originalCircles, testCricle))
        {
            originalCircles.push(testCricle);
        }
    }}
    return originalCircles;
}

function generateCirclePopulation(numberOfCircles, biggestCircle = null)
{
    var population = [];
    if(biggestCircle != null)
        population.push(biggestCircle);
    while(population.length != numberOfCircles)
    {
        var x = Math.floor(Math.random()*800);
        var y = Math.floor(Math.random()*800);
        var r = Math.floor(Math.random()*600);
        var testCricle = new Circle(x, y, r);
        if(circleInsideCanvas(testCricle)){
        if(!circleCollidesWithArrayOfCircles(originalCircles, testCricle))
        {
            population.push(testCricle);
        }
    }}
    return population;
}
var originalCircles = generateOriginalPopulation(25);


function addZeros(value)
{
    returnString = value;
    for (let i = 0; i < 10 - value.length; i++) {
        returnString = "0" + returnString;
    }
    return returnString;
}

//function to check if circle inside canvas
function circleInsideCanvas(circle){
    if(circle.x + circle.r > 800 || circle.x - circle.r < 0)
        return false;
    if(circle.y + circle.r > 800 || circle.y - circle.r < 0)
        return false;
    
    return true;
}

//function to check one circle if it collides with the array of circles
function circleCollidesWithArrayOfCircles(circleArray, circle)
{
    for (let i = 0; i < circleArray.length; i++) {
        if(isTwoCirclesCollides(circle, circleArray[i]))
        {
            return true;
        }   
    }
    return false;
}
function isTwoCirclesCollides(Circle1, Circle2){
	var dis = Math.sqrt((Circle1.x - Circle2.x)*(Circle1.x - Circle2.x) +(Circle1.y - Circle2.y)*(Circle1.y - Circle2.y) );
	if ((dis < Circle1.r + Circle2.r)||(dis < Math.abs (Circle1.r - Circle2.r)))
	{
		return true;
	}
	else
		return false;
}
function getMaxRadius(population, biggestCircle)
{
    var max = biggestCircle  ;
    for (let i = 0; i < population.length; i++) {
        if(max.r < population[i].r)
            max = population[i];
    }
    return max;
}
function DistanceBetweenTwoCircle(circle1, circle2)
{   
    return Math.sqrt(Math.abs((circle1.r * circle2.r) - (manhattenDistance(circle1, circle2) / 2 * manhattenDistance(circle1, circle2) / 2))) 
    + Math.sqrt(Math.abs((circle1.r * circle2.r) - (manhattenDistance(circle1, circle2) / 2 * manhattenDistance(circle1, circle2) / 2)));
}
function manhattenDistance(circle1, circle2)
{
    return Math.abs(circle1.x - circle2.x) + Math.abs(circle1.y - circle2.y);
}

function Mutation(circle1, circle2)
{
    var newBaby1 = toBinary(circle1);
    var newBaby2 = toBinary(circle2);
    var indexToSplit =  Math.floor(Math.random() * (29 - 0)) + 0;
    var subString1 = newBaby1.substring(indexToSplit);
    var subString2 = newBaby2.substring(indexToSplit);
    newBaby1 = newBaby1.substring(0 , indexToSplit);
    newBaby2 = newBaby2.substring(0 , indexToSplit);
    newBaby1 = newBaby1 + subString2;
    newBaby2 = newBaby2 + subString1;
    var indexToSplit1 =  Math.floor(Math.random() * (29 - 0)) + 0;
    var indexToSplit2 =  Math.floor(Math.random() * (29 - 0)) + 0;
    var subString1 = newBaby1.substring(indexToSplit1);
    var subString2 = newBaby2.substring(indexToSplit2);
    for(i = 0; i < subString1.length; i++)
    {
        if(subString1.charAt(i) == "0")
        {
            subString1 =  replaceChar(subString1, "1", i);
        }
        else
        {
            subString1 = replaceChar(subString1, "0", i);
        }
    }
    for(i = 0; i < subString2.length; i++)
    {
        if(subString2.charAt(i) == "0")
        {
            subString2 = replaceChar(subString2, "1", i);
        }
        else
        {
            subString2 = replaceChar(subString2, "0", i);
        }
    }

    newBaby1 = newBaby1.substring(0 , indexToSplit1);
    newBaby2 = newBaby2.substring(0 , indexToSplit2);
    newBaby1 = newBaby1 + subString1;
    newBaby2 = newBaby2 + subString2;

    return baby = {
        newBaby1 : newBaby1, 
        newBaby2 : newBaby2
    };
}
function replaceChar(origString, replaceChar, index) {
    let firstPart = origString.substr(0, index);
    let lastPart = origString.substr(index + 1);
      
    let newString = firstPart + replaceChar + lastPart;
    return newString;
}
count = 0;
function createGeneration(population)
{
    newGeneration = [];
    i = 0;
    while(newGeneration.length != 199)
    {
        var parent1 = population[i];
        i++;
        var parent2 = population[i];
        var baby = Mutation(parent1, parent2);
        var baby1 = convertToInt(baby.newBaby1);
        var baby2 = convertToInt(baby.newBaby2);
        if(circleInsideCanvas(baby1))
        if(!circleCollidesWithArrayOfCircles(originalCircles ,baby1))
            newGeneration.push(baby1);

            if(newGeneration.length == 199)
                break;
        if(circleInsideCanvas(baby2))
        if(!circleCollidesWithArrayOfCircles(originalCircles ,baby2))
            newGeneration.push(baby2);

        if(i % 199 == 0)
            i = 0;
    }

    return newGeneration;
}
function convertToInt(str)
{
    var x = str.substring(0, 9);
    var y = str.substring(10, 19);
    var r = str.substring(20, 29);
    x = parseInt(x, 2);
    y = parseInt(y, 2);
    r = parseInt(r, 2);
    var resultCircle = new Circle(x, y, r);
    return resultCircle;
}
function start(pop, biggestCircle)
{
    var newGen = createGeneration(pop);
    newGen.push(biggestCircle);
    count++;
    console.log(count);
    var biggestCircle = getMaxRadius(newGen, biggestCircle);
    ctx.clearRect(0, 0, 800, 800);
    draw(originalCircles, 'black');
    draw([biggestCircle], 'green');
    requestAnimationFrame(function(){
        start(pop, biggestCircle);
    });  
}
var ogPopulation = generateCirclePopulation(200);
var test = new Circle(0,0,0);
start(ogPopulation, test);

function draw(arrayOfCircles , color)
{
    for (let i = 0; i < arrayOfCircles.length; i++) {
        ctx.beginPath();
        ctx.arc(arrayOfCircles[i].x, arrayOfCircles[i].y, arrayOfCircles[i].r, 0, 2 * Math.PI, false);
        ctx.lineWidth = 2;
        if(color === 'green')
        {
            ctx.fillStyle = color;
            ctx.fill();
            
        }
        ctx.strokeStyle = color;
        ctx.stroke();
    }
}